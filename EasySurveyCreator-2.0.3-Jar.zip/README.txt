---- README ----

IMPORTANT NOTE: Windows antivirus software will block the Easy Survey Creator installation. In order to install this application you must either disable your antivirus during installation or whitelist the installer.

COPYRIGHT NOTICE: By downloading, recieving, installing or using The Easy Survey Creator you agree to the terms of the CC BY-ND license, under which it is licensed. https://creativecommons.org/licenses/by-nd/4.0/


Version 2.0.3 Jar - Third Stable Release. The Jar file is a standalone application that can be run on any system with Java JRE 7 or greater.

Version 2.0.3 - Third Stable Release. Version 2.0.3 improves the installation of the Easy Survey Creator using inno5 and exe4j. It also fixes issues with the analysis menu.

Version 2.0.2 - Second Stable Release. Version 2.0.2 adds more intuitive menu systems for creating and analyzing surveys. It also fixes multiple bugs in 2.0.

Version 2.0 - Initial Stable Release.

--- INSTALLATION ---

Release 2.0.3 is the newest release, and is recommended. This Jar file is a standalone application that can be run on any system with Java JRE 7 or greater.


--- KNOWN ISSUES ---

- During installation Error 5 access denied: "Unable to execute file in the temporary directory. Setup aborted"

SOLUTION: Disable antivirus software temporarily and restart the installer. Right-click on the installer and run as administrator. If issue continues add the installer to your antivirus's whitelist.

- During installation ShellExecuteEx failed; code 299: "Only part of a ReadProcessMemory or WriteProcessMemory request was completed"

SOLUTION: Disable antivirus software temporarily and restart the installer. Right-click on the installer and run as administrator. If issue continues add the installer to your antivirus's whitelist.